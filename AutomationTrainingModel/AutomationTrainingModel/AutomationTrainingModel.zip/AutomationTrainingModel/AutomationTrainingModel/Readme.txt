This is a function prototype for Automated Training model rev 2

The software will cross reference user input to the text documents in the folder.
Currently only some faults were programmed from a Fanuc R30ib controller. 
As revisions change, more information will be inputted to the text documents.

To run: Open Fault Search_13_JUL_2023

Dialog box will open asking the end user if it is a robot or machine issue. Ex: If the user wants robotic information they would click the robot icon.
Once an option is chosen, the end user will be prompted to enter some information that will be cross checked with the information stored.
